﻿using Microsoft.AspNetCore.Identity;

namespace APACExportTrackX.DataModel
{
	public class ApplicationUser : IdentityUser
	{
		public override string Id { get; set; } = Guid.NewGuid().ToString();
		public int EmpId { get; set; }
		public string CitrixId { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public bool IsActive { get; set; } = true;
		public bool IsDelete { get; set; } = false;
        public bool? IsLDAP { get; set; } = false;
        public bool? IsReset { get; set; } = false;
        public virtual ICollection<FileActivityLog> FileActivityLogs { get; } = new List<FileActivityLog>();
		public virtual ICollection<HBLActivityLog> HBLActivityLogs { get; } = new List<HBLActivityLog>();
	}
}