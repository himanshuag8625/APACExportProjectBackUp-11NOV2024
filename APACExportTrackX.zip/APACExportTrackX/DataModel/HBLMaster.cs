﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace APACExportTrackX.DataModel
{

    public partial class HBLMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString(); 
        public string HBLNumber { get; set; } = null!;
        public string ContainerId { get; set; }
        public string? CustomerName { get; set; } = null!;
        public string? Booking { get; set; } = null!;

        public DateTime? EnterDate { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool? IsDelete { get; set; } = false;
        
        [ForeignKey("ContainerId")]
        public virtual ContainerMaster ContainerMaster { get; set; } 

        public virtual ICollection<HBLActivityLog> HBLActivityLogs { get; } = new List<HBLActivityLog>();
    }
}