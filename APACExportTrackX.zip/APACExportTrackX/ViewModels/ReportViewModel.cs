﻿namespace APACExportTrackX.ViewModels
{
    public class ReportViewModel
    {
        public string ReportType { get; set; }
        public string DateType { get; set; }
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
    }
}
