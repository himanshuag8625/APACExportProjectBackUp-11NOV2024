﻿using ClosedXML.Excel;
using APACExportTrackX.DataModel;
using APACExportTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Reflection;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Text.RegularExpressions;

namespace APACExportTrackX.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        ApplicationDBContext _context;
        public DashboardController(ApplicationDBContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public async Task<IActionResult> Index()
        {
            ViewData["StatusMaster"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ApplicationUser"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityMaster"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public IActionResult GetFiles(string activity, string Country, string fileNumber, string search, string status)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);

            List<FileDashModel> fileDashModel = new List<FileDashModel>();

            //var data = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= date.Date - TimeSpan.FromDays(10) || x.SICutOff.Value.Date == null).Include(x => x.FileMaster).Include(x => x.FileActivityLogs).ThenInclude(x => x.ApplicationUser).Select(x => new FileDashModel
            var data = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null).Include(x => x.FileMaster).Include(x => x.FileActivityLogs).ThenInclude(x => x.ApplicationUser).Select(x => new FileDashModel
            {
                Id = x.FileMaster.Id,
                FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                EnterDate = x.FileMaster.EnterDate,
                FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                POD = x.FileMaster.CountryMaster.CountryName,
                ETD = x.FileMaster.ETD,
                ETAPOD = x.FileMaster.ETAPOD,
                ETA = x.FileMaster.ETA,
                ATD = x.FileMaster.ATD,
                SICutOff = x.SICutOff,
                ShippingLine = x.FileMaster.ShippingLine,
                FileContact = x.FileMaster.FileContact,
                FileActivityLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Id,
                UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                ContainerNo = x.ContainerNo,
                ContainerId = x.Id,
                Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                Roe = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Roe != null).FirstOrDefault().Roe,
                EndDate = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().EndDate,
                TallySheetId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().Status.Status ?? "UnAllocated",
                TallySheetCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().EndDate,
                MblReviewId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().Status.Status ?? "UnAllocated",
                MblReviewCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().EndDate,
                TblProcessingId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().Status.Status ?? "UnAllocated",
                TblProcessingCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().EndDate,
                TallySheetComment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().Comment ?? "",
                MblReviewComment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().Comment ?? "",
                TblProcessingComment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().Comment ?? "",
                CarrierRequest = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Carrier Request").FirstOrDefault().Status.Status ?? "UnAllocated",
                CarrierRequestCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Carrier Request").FirstOrDefault().EndDate,
                BLRequestId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "BL Request").FirstOrDefault().Status.Status ?? "UnAllocated",
                BLRequestCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "BL Request").FirstOrDefault().EndDate,
                BLRequestComment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "BL Request").FirstOrDefault().Comment ?? "",
                BLRequest = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "BL Request").FirstOrDefault().Status.Status ?? "UnAllocated",
                TBLProcessing = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().Status.Status ?? "UnAllocated",
                TBLProcessCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().EndDate,
                TallySheetChecking = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().Status.Status ?? "UnAllocated",
                TallySheetCheckingCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().EndDate,
                SIToCarrier = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().Status.Status ?? "UnAllocated",
                SIToCarrierCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().EndDate,
                MBLReview = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().Status.Status ?? "UnAllocated",
                MBLReviewsCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().EndDate,
                Invoice = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent").FirstOrDefault().Status.Status ?? "UnAllocated",
                InvoiceCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent").FirstOrDefault().EndDate,
                FinalBL = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer").FirstOrDefault().Status.Status ?? "UnAllocated",
                FinalBLCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer").FirstOrDefault().EndDate,
                PreAlert = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert").FirstOrDefault().Status.Status ?? "UnAllocated",
                PreAlertCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert").FirstOrDefault().EndDate,
                Permit = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Permit").FirstOrDefault().Status.Status ?? "UnAllocated",
                PermitCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Permit").FirstOrDefault().EndDate,
                LBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count(),
                TBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
                TotalHBL = x.HBLMasters.Where(y => y.ContainerId == x.Id).Count() != 0 ? (x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : x.FileMaster.TotalBL
            }).AsQueryable();

            IQueryable<FileDashModel> SortedData = data.AsQueryable();

            if (date != null)
            {
                //SortedData = SortedData.Where(x => x.SICutOff.Value.Date >= date.Date - TimeSpan.FromDays(10) || x.SICutOff.Value.Date == null);
                SortedData = SortedData.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null);
            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--" && activity != "-- Select Activities --")
            {
                switch (activity)
                {
                    case "SI To Carrier":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.SIToCarrier == status && x.BLRequest == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.BLRequest == "Completed" && x.SIToCarrier != "Completed");
                        }
                        break;
                    case "BL Request":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.BLRequest == status && x.CarrierRequest == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.CarrierRequest == "Completed" && x.BLRequest != "Completed");
                        }
                        break;
                    case "Final BL To Invoices Customer":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.FinalBL == status && x.SIToCarrier == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.SIToCarrier == "Completed" && x.FinalBL != "Completed");
                        }
                        break;
                    case "Pre-Alert":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.PreAlert == status && x.FinalBL == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.FinalBL == "Completed" && x.PreAlert != "Completed");
                        }
                        break;
                    case "Permit":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.Permit == status && x.PreAlert == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.PreAlert == "Completed" && x.Permit != "Completed");
                        }
                        break;
                    case "Invoices To POD Agent":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.Invoice == status && x.Permit == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.Permit == "Completed" && x.Invoice != "Completed");
                        }
                        break;
                    case "Carrier Request":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.CarrierRequest == status);
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.CarrierRequest != "Completed");
                        }
                        break;
                    case "TBL Processing":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.TBLProcessing == status && x.CarrierRequest == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.CarrierRequest == "Completed" && x.TBLProcessing != "Completed");
                        }
                        break;
                    case "Tally Sheet":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.TallySheetChecking == status && x.CarrierRequest == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.CarrierRequest == "Completed" && x.TallySheetChecking != "Completed");
                        }
                        break;
                    case "MBL Review":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.MBLReview == status && x.CarrierRequest == "Completed");
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.CarrierRequest == "Completed" && x.MBLReview != "Completed");
                        }
                        break;
                    default:
                        if (string.IsNullOrEmpty(status) && status == "none" && status == "--Select--" && status == "-- Select Status --")
                        {
                            status = "UnAllocated";
                        }
                        SortedData = SortedData.Where(x => (x.ActivityId != activity.Trim() && x.StatusId == status) || (x.ActivityId == activity.Trim() && x.StatusId != "Completed"));
                        break;
                }
            }

            if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
                search == "Received" || search == "UnAllocated" || search == "etd10" || search == "etd12" || search == "etd18" || search == "si")
            {
                switch (search)
                {
                    case "etd10":
                        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.AddDays(-10) <= DateTime.Now && x.StatusId != "Completed");
                        break;
                    case "etd12":
                        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.AddDays(-10) > DateTime.Now && x.ETD.Value.AddDays(-12) <= DateTime.Now && x.StatusId != "Completed");
                        break;
                    case "etd18":
                        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.AddDays(-12) > DateTime.Now && x.StatusId != "Completed");
                        break;
                    case "Received":
                        break; // No filtering needed
                    case "UnAllocated":
                        SortedData = SortedData.Where(x => x.StatusId == "UnAllocated");
                        break;
                    case "si":
                        SortedData = SortedData.Where(x => x.StatusId != "Completed" && x.SICutOff != null && x.SICutOff.Value.Date == DateTime.Today);
                        break;
                    case "Pending":
                        SortedData = SortedData.Where(x => (x.StatusId == "Pending" || x.StatusId == "Completed With Query") && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today);
                        break;
                    default:
                        SortedData = SortedData.Where(x => x.StatusId == search && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today);
                        break;
                }
            }

            //if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //{
            //    if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--" && activity != "-- Select Activities --")
            //    {
            //        switch (activity)
            //        {
            //            case "SI To Carrier":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.SIToCarrier == status && x.CarrierRequest == "Completed");
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.CarrierRequest == "Completed" && x.SIToCarrier != "Completed");
            //                }
            //                break;
            //            case "Final BL To Invoices Customer":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.FinalBL == status && x.SIToCarrier == "Completed");
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.SIToCarrier == "Completed" && x.FinalBL != "Completed");
            //                }
            //                break;
            //            case "Pre-Alert":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.PreAlert == status && x.FinalBL == "Completed");
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.FinalBL == "Completed" && x.PreAlert != "Completed");
            //                }
            //                break;
            //            case "Permit":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.Permit == status && x.PreAlert == "Completed");
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.PreAlert == "Completed" && x.Permit != "Completed");
            //                }
            //                break;
            //            case "Invoices To POD Agent":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.Invoice == status && x.Permit == "Completed");
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.Permit == "Completed" && x.Invoice != "Completed");
            //                }
            //                break;
            //            case "Carrier Request":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.CarrierRequest == status);
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.CarrierRequest != "Completed");
            //                }
            //                break;
            //            case "TBL Processing":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.TBLProcessing == status && x.CarrierRequest == "Completed");
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.CarrierRequest == "Completed" && x.TBLProcessing != "Completed");
            //                }
            //                break;
            //            case "Tally Sheet":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.TallySheetChecking == status && x.CarrierRequest == "Completed");
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.CarrierRequest == "Completed" && x.TallySheetChecking != "Completed");
            //                }
            //                break;
            //            case "MBL Review":
            //                if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            //                {
            //                    SortedData = SortedData.Where(x => x.MBLReview == status && x.CarrierRequest == "Completed");
            //                }
            //                else
            //                {
            //                    SortedData = SortedData.Where(x => x.CarrierRequest == "Completed" && x.MBLReview != "Completed");
            //                }
            //                break;
            //            default:
            //                if (string.IsNullOrEmpty(status) && status == "none" && status == "--Select--" && status == "-- Select Status --")
            //                {
            //                    status = "UnAllocated";
            //                }
            //                SortedData = SortedData.Where(x => (x.ActivityId != activity.Trim() && x.StatusId == status) || (x.ActivityId == activity.Trim() && x.StatusId != "Completed"));
            //                break;
            //        }
            //    }
            //    else if (status == "UnAllocated")
            //    {
            //        SortedData = SortedData.Where(x => x.StatusId == "UnAllocated" && x.UserId == "");
            //    }
            //    else
            //    {
            //        SortedData = SortedData.Where(x => x.StatusId == status.Trim());
            //    }
            //}

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "enterDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection);
            }

            const string UTCTimeZoneId = "UTC";
            const string SGTTimeZoneId = "Singapore Standard Time";
            var utcTimeZone = TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZoneId);
            var sgtTimeZone = TimeZoneInfo.FindSystemTimeZoneById(SGTTimeZoneId);

            //SortedData = SortedData.Select(x => new FileDashModel
            //{
            //    Id = x.Id,
            //    FileLogId = x.FileLogId,
            //    EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, sgtTimeZone) : (DateTime?)null,
            //    FileNumber = x.FileNumber,
            //    POD = x.POD,
            //    ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, sgtTimeZone) : (DateTime?)null,
            //    ETAPOD = x.ETAPOD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAPOD.Value, sgtTimeZone) : (DateTime?)null,
            //    ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, sgtTimeZone) : (DateTime?)null,
            //    ATD = x.ATD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ATD.Value, sgtTimeZone) : (DateTime?)null,
            //    SICutOff = x.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SICutOff.Value, sgtTimeZone) : (DateTime?)null,
            //    ShippingLine = x.ShippingLine,
            //    FileContact = x.FileContact,
            //    FileActivityLogId = x.FileActivityLogId,
            //    UserId = x.UserId,
            //    StatusId = x.StatusId,
            //    ActivityId = x.ActivityId,
            //    ActivityType = x.ActivityType,
            //    ContainerNo = x.ContainerNo,
            //    ContainerId = x.ContainerId,
            //    Comment = x.Comment,
            //    Roe = x.Roe,
            //    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, sgtTimeZone) : (DateTime?)null,
            //    TallySheetId = x.TallySheetId,
            //    TallySheetCompleted = x.TallySheetCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.TallySheetCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    MblReviewId = x.MblReviewId,
            //    MblReviewCompleted = x.MblReviewCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.MblReviewCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    TblProcessingId = x.TblProcessingId,
            //    TblProcessingCompleted = x.TblProcessingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.TblProcessingCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    TallySheetComment = x.TallySheetComment,
            //    MblReviewComment = x.MblReviewComment,
            //    TblProcessingComment = x.TblProcessingComment,
            //    CarrierRequest = x.CarrierRequest,
            //    CarrierRequestCompleted = x.CarrierRequestCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.CarrierRequestCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    BLRequestId = x.BLRequestId,
            //    BLRequestCompleted = x.BLRequestCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.BLRequestCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    BLRequestComment = x.BLRequestComment,
            //    BLRequest = x.BLRequest,
            //    TBLProcessing = x.TBLProcessing,
            //    TBLProcessCompleted = x.TBLProcessCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.TBLProcessCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    TallySheetChecking = x.TallySheetChecking,
            //    TallySheetCheckingCompleted = x.TallySheetCheckingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.TallySheetCheckingCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    SIToCarrier = x.SIToCarrier,
            //    SIToCarrierCompleted = x.SIToCarrierCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SIToCarrierCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    MBLReview = x.MBLReview,
            //    MBLReviewsCompleted = x.MBLReviewsCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.MBLReviewsCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    Invoice = x.Invoice,
            //    InvoiceCompleted = x.InvoiceCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.InvoiceCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    FinalBL = x.FinalBL,
            //    FinalBLCompleted = x.FinalBLCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FinalBLCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    PreAlert = x.PreAlert,
            //    PreAlertCompleted = x.PreAlertCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.PreAlertCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    Permit = x.Permit,
            //    PermitCompleted = x.PermitCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.PermitCompleted.Value, sgtTimeZone) : (DateTime?)null,
            //    LBL = x.LBL,
            //    TBL = x.TBL,
            //    TotalHBL = x.TotalHBL
            //}).AsQueryable();
            
            SortedData = SortedData.Select(x => new FileDashModel
            {
                Id = x.Id,
                FileLogId = x.FileLogId,
                EnterDate = x.EnterDate.HasValue ? x.EnterDate.Value.AddHours(5.5) : (DateTime?)null,
                FileNumber = x.FileNumber,
                POD = x.POD,
                ETD = x.ETD.HasValue ? x.ETD.Value.AddHours(5.5) : (DateTime?)null,
                ETAPOD = x.ETAPOD.HasValue ? x.ETAPOD.Value.AddHours(5.5) : (DateTime?)null,
                ETA = x.ETA.HasValue ? x.ETA.Value.AddHours(5.5) : (DateTime?)null,
                ATD = x.ATD.HasValue ? x.ATD.Value.AddHours(5.5) : (DateTime?)null,
                //SICutOff = x.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SICutOff.Value, sgtTimeZone) : (DateTime?)null,
                SICutOff = x.SICutOff.HasValue ? x.SICutOff.Value : (DateTime?)null,
                ShippingLine = x.ShippingLine,
                FileContact = x.FileContact,
                FileActivityLogId = x.FileActivityLogId,
                UserId = x.UserId,
                StatusId = x.StatusId,
                ActivityId = x.ActivityId,
                ActivityType = x.ActivityType,
                ContainerNo = x.ContainerNo,
                ContainerId = x.ContainerId,
                Comment = x.Comment,
                Roe = x.Roe,
                EndDate = x.EndDate.HasValue ? x.EndDate.Value.AddHours(5.5) : (DateTime?)null,
                TallySheetId = x.TallySheetId,
                TallySheetCompleted = x.TallySheetCompleted.HasValue ? x.TallySheetCompleted.Value.AddHours(5.5) : (DateTime?)null,
                MblReviewId = x.MblReviewId,
                MblReviewCompleted = x.MblReviewCompleted.HasValue ? x.MblReviewCompleted.Value.AddHours(5.5) : (DateTime?)null,
                TblProcessingId = x.TblProcessingId,
                TblProcessingCompleted = x.TblProcessingCompleted.HasValue ? x.TblProcessingCompleted.Value.AddHours(5.5) : (DateTime?)null,
                TallySheetComment = x.TallySheetComment,
                MblReviewComment = x.MblReviewComment,
                TblProcessingComment = x.TblProcessingComment,
                CarrierRequest = x.CarrierRequest,
                CarrierRequestCompleted = x.CarrierRequestCompleted.HasValue ? x.CarrierRequestCompleted.Value.AddHours(5.5) : (DateTime?)null,
                BLRequestId = x.BLRequestId,
                BLRequestCompleted = x.BLRequestCompleted.HasValue ? x.BLRequestCompleted.Value.AddHours(5.5) : (DateTime?)null,
                BLRequestComment = x.BLRequestComment,
                BLRequest = x.BLRequest,
                TBLProcessing = x.TBLProcessing,
                TBLProcessCompleted = x.TBLProcessCompleted.HasValue ? x.TBLProcessCompleted.Value.AddHours(5.5) : (DateTime?)null,
                TallySheetChecking = x.TallySheetChecking,
                TallySheetCheckingCompleted = x.TallySheetCheckingCompleted.HasValue ? x.TallySheetCheckingCompleted.Value.AddHours(5.5) : (DateTime?)null,
                SIToCarrier = x.SIToCarrier,
                SIToCarrierCompleted = x.SIToCarrierCompleted.HasValue ? x.SIToCarrierCompleted.Value.AddHours(5.5) : (DateTime?)null,
                MBLReview = x.MBLReview,
                MBLReviewsCompleted = x.MBLReviewsCompleted.HasValue ? x.MBLReviewsCompleted.Value.AddHours(5.5) : (DateTime?)null,
                Invoice = x.Invoice,
                InvoiceCompleted = x.InvoiceCompleted.HasValue ? x.InvoiceCompleted.Value.AddHours(5.5) : (DateTime?)null,
                FinalBL = x.FinalBL,
                FinalBLCompleted = x.FinalBLCompleted.HasValue ? x.FinalBLCompleted.Value.AddHours(5.5) : (DateTime?)null,
                PreAlert = x.PreAlert,
                PreAlertCompleted = x.PreAlertCompleted.HasValue ? x.PreAlertCompleted.Value.AddHours(5.5) : (DateTime?)null,
                Permit = x.Permit,
                PermitCompleted = x.PermitCompleted.HasValue ? x.PermitCompleted.Value.AddHours(5.5) : (DateTime?)null,
                LBL = x.LBL,
                TBL = x.TBL,
                TotalHBL = x.TotalHBL
            }).AsQueryable();

            //SortedData = SortedData.Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize);

            var returnObj = new
            {
                draw = draw,
                recordsTotal = data.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData.ToList()
            };

            return Json(returnObj);
        }

        [HttpGet]
        public IActionResult GetHblData(string id)
        {
            const string UTCTimeZoneId = "UTC";
            const string SGTTimeZoneId = "Singapore Standard Time";
            const string ISTTimeZoneId = "India Standard Time";
            var utcTimeZone = TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZoneId);
            var sgtTimeZone = TimeZoneInfo.FindSystemTimeZoneById(SGTTimeZoneId);
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);
            var sm = _context.StatusMaster.ToList();

            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerId == id).Select(x => new FileDashModel
            {
                ContainerId = x.ContainerId,
                ActivityId = x.Activity.NameOfActivity,
                StatusId = x.Status.Status,
                UserId = x.ApplicationUser.UserName,
                Comment = x.Comment,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                LBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count(),
                TBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count(),
                TotalHBL = (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count())
            }).ToList();

            fm = fm.OrderBy(x => x.EndDate).Select(x => new FileDashModel
            {
                ContainerId = x.ContainerId,
                ActivityId = x.ActivityId,
                StatusId = x.StatusId,
                UserId = x.UserId == null ? "" : x.UserId,
                Comment = x.Comment == null ? "" : x.Comment,
                StartDate = x.StartDate.HasValue ? x.StartDate.Value.AddHours(5.5) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? x.EndDate.Value.AddHours(5.5) : (DateTime?)null,
                LBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count(),
                TBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count(),
                TotalHBL = (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count())
            }).ToList();

            var hblIdList = _context.HBLMaster.Where(x => x.ContainerId == id).Select(x => x.Id).ToList();
            var hbl = new List<HBLDashViewModel>();

            foreach (var hblId in hblIdList)
            {
                var hblActivityLogRecords = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Hbl.ContainerMaster)
                    .Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.HBLId == hblId)
                    .Select(x => new HBLDashViewModel
                    {
                        Id = x.HBLId,
                        ContainerNo = x.Hbl.ContainerMaster.ContainerNo,
                        FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                        HBLNumber = x.Hbl.HBLNumber,
                        CustomerName = x.Hbl.CustomerName == null ? "" : x.Hbl.CustomerName,
                        BookingNo = x.Hbl.Booking,
                        Activity = x.Activity.NameOfActivity,
                        Status = x.Status.Status,
                        Comment = x.Comment == null ? "" : x.Comment ,
                        User = x.ApplicationUser.UserName,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                    }).ToList();

                 hblActivityLogRecords = hblActivityLogRecords.OrderBy(x => x.EndDate).Select(x => new HBLDashViewModel
                   {
                       Id = x.Id,
                       ContainerNo = x.ContainerNo,
                       FileNumber = x.FileNumber,
                       HBLNumber = x.HBLNumber,
                       CustomerName = x.CustomerName == null ? "" : x.CustomerName,
                       BookingNo = x.BookingNo,
                       Activity = x.Activity == null ? "" : x.Activity,
                       Status = x.Status == null ? "" : x.Status,
                       Comment = x.Comment == null ? "" : x.Comment,
                       User = x.User,
                       StartDate = x.StartDate.HasValue ? x.StartDate.Value.AddHours(5.5) : (DateTime?)null,
                       EndDate = x.EndDate.HasValue ? x.EndDate.Value.AddHours(5.5) : (DateTime?)null,
                 }).ToList();

                hbl.AddRange(hblActivityLogRecords);
            }
            fm = fm.OrderByDescending(x => x.EndDate).ThenBy(x => x.ActivityId).ToList();
            hbl = hbl.OrderByDescending(x => x.EndDate).ThenBy(x => x.Activity).ToList();
            return Json(new { fm, hbl, sm });
        }

        [HttpGet]
        public IActionResult GetHblDataGetHblData(string id)
        {
            var hbl = _context.HBLMaster.Where(x => x.ContainerId == id).ToList();
            var sm = _context.StatusMaster.ToList();
            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerMaster.Id == id).ToList();

            return Json(new { fm, hbl, sm });
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string id)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.HBLId == id).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                }).ToList();
            }
            return Json(hblact);
        }


        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult GetDashboardCount(string? activity)
        {
            var fileActivityLogs = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Status).Include(x => x.ApplicationUser).ToList();
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);
            var data = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null).Include(x => x.FileMaster).Include(x => x.FileActivityLogs).ThenInclude(x => x.ApplicationUser).Select(x => new FileDashModel
            {
                Id = x.FileMaster.Id,
                FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                EnterDate = x.FileMaster.EnterDate,
                FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                POD = x.FileMaster.CountryMaster.CountryName,
                ETD = x.FileMaster.ETD,
                ETAPOD = x.FileMaster.ETAPOD,
                ETA = x.FileMaster.ETA,
                ATD = x.FileMaster.ATD,
                SICutOff = x.SICutOff,
                ShippingLine = x.FileMaster.ShippingLine,
                FileContact = x.FileMaster.FileContact,
                UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                ContainerNo = x.ContainerNo,
                ContainerId = x.Id,
                Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                EndDate = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().EndDate,
            }).AsQueryable();

            var currentDate = DateTime.UtcNow.Date;
            if (date != null)
            {
                data = data.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null);
            }
            DashboardProdcount dp = new DashboardProdcount
            {
                Received = data.Count(),
                Pending = data.Count(x => (x.StatusId == "Pending" || x.StatusId == "Completed With Query") && x.EndDate != null && x.EndDate.Value.Date == currentDate),
                WIP = data.Count(x => x.StatusId == "WIP" && x.EndDate != null && x.EndDate.Value.Date == currentDate),
                Query = data.Count(x => x.StatusId == "Query" && x.EndDate != null && x.EndDate.Value.Date == currentDate),
                Completed = data.Count(x => x.StatusId == "Completed" && x.EndDate != null && x.EndDate.Value.Date == currentDate),
                UnAllocated = data.Count(x => x.StatusId == "UnAllocated"),
                siCutOff = data.Count(x => x.SICutOff != null && x.SICutOff.Value.Date == currentDate && x.StatusId != "Completed"),
            };

            return Json(dp);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public ActionResult Report()
        {
            return View();
        }

        //Report download
        [HttpPost]
        public ActionResult Report(ReportViewModel report)
        {
            DataTable fileactivity = new DataTable();
            DataTable hblactivity = new DataTable();
            var fileactivtydata = new List<FileReportViewModel>();
            var HBLdata = new List<HBLReportViewModel>();
            var getFileActivityStatus = new List<FileActivityStatusList>();
            var getHBLActivityStatus = new List<HBLActivityStatusList>();
            var fileActivityList = new List<FileActivityLog>();
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();            
            var fileActivitys = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var hblActivitys = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.NameOfActivity).ToList();
            var userList = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            //Adhoc Report 
            DataTable adhoc = new DataTable();
            DataTable adhocHBL = new DataTable();
            DataTable adhocfileActivity = new DataTable();
            DataTable adhochblActivity = new DataTable();
            var startDate = report.start_date;
            var endDate = report.end_date;
            IQueryable<ApplicationUser> udata = _context.Set<ApplicationUser>().AsQueryable();
            DataTable dt = new DataTable();
            const string UTCTimeZoneId = "UTC";
            const string SGTTimeZoneId = "Singapore Standard Time";
            var utcTimeZone = TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZoneId);
            var sgtTimeZone = TimeZoneInfo.FindSystemTimeZoneById(SGTTimeZoneId);

            if (report.start_date != null && report.end_date != null)
            {
                if (report.ReportType == "File")
                {
                    dt.Columns.Add("Received Date");
                    dt.Columns.Add("File Number");
                    dt.Columns.Add("Container Number");
                    dt.Columns.Add("SI Cut Off");
                    dt.Columns.Add("User");
                    dt.Columns.Add("Activity");
                    dt.Columns.Add("Status");
                    dt.Columns.Add("Comment");
                    dt.Columns.Add("ROE");

                    if (report.DateType == "ReceivedDate")
                    {
                        fileactivtydata = _context.FileActivityLog.Where(x => x.ContainerMaster.FileMaster.EnterDate.Value.Date >= startDate.Date &&
                                             x.ContainerMaster.FileMaster.EnterDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 EnterDate = x.ContainerMaster.FileMaster.EnterDate,
                                                 FileNumber = x.ContainerMaster.FileMaster.FileNumber,
                                                 ContainerNo = x.ContainerMaster.ContainerNo,
                                                 SICutOff = x.ContainerMaster.SICutOff,
                                                 UserId = x.ApplicationUser.CitrixId,
                                                 ActivityId = x.Activity.NameOfActivity,
                                                 StatusId = x.Status.Status,
                                                 Comment = x.Comment,
                                                 Roe = x.Roe
                                             }).ToList();
                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            EnterDate = x.EnterDate.HasValue ? x.EnterDate.Value.AddHours(5.5) : (DateTime?)null,
                            FileNumber = x.FileNumber,
                            ContainerNo = x.ContainerNo,
                            //SICutOff = x.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SICutOff.Value, sgtTimeZone) : (DateTime?)null,
                            SICutOff = x.SICutOff.HasValue ? x.SICutOff : (DateTime?)null,
                            UserId = x.UserId,
                            ActivityId = x.ActivityId,
                            StatusId = x.StatusId,
                            Comment = x.Comment,
                            Roe = x.Roe
                        }).ToList();
                    }
                    else if ((report.DateType == "EndDate"))
                    {
                        fileactivtydata = _context.FileActivityLog.Where(x => x.EndDate.Value.Date >= startDate.Date &&
                                             x.EndDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 EnterDate = x.ContainerMaster.FileMaster.EnterDate,
                                                 FileNumber = x.ContainerMaster.FileMaster.FileNumber,
                                                 ContainerNo = x.ContainerMaster.ContainerNo,
                                                 SICutOff = x.ContainerMaster.SICutOff,
                                                 ActivityId = x.Activity.NameOfActivity,
                                                 StatusId = x.Status.Status,
                                                 Comment = x.Comment,
                                                 Roe = x.Roe
                                             }).ToList();

                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            EnterDate = x.EnterDate.HasValue ? x.EnterDate.Value.AddHours(5.5) : (DateTime?)null,
                            FileNumber = x.FileNumber,
                            ContainerNo = x.ContainerNo,
                            //SICutOff = x.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SICutOff.Value, sgtTimeZone) : (DateTime?)null,
                            SICutOff = x.SICutOff.HasValue ? x.SICutOff : (DateTime?)null,
                            UserId = x.UserId,
                            ActivityId = x.ActivityId,
                            StatusId = x.StatusId,
                            Comment = x.Comment,
                            Roe = x.Roe
                        }).ToList();
                    }
                    else
                    {
                        fileactivtydata = _context.FileActivityLog.Where(x => x.StartDate.Value.Date >= startDate.Date &&
                                             x.StartDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 EnterDate = x.ContainerMaster.FileMaster.EnterDate,
                                                 FileNumber = x.ContainerMaster.FileMaster.FileNumber,
                                                 ContainerNo = x.ContainerMaster.ContainerNo,
                                                 SICutOff = x.ContainerMaster.SICutOff,
                                                 ActivityId = x.Activity.NameOfActivity,
                                                 StatusId = x.Status.Status,
                                                 Comment = x.Comment,
                                                 Roe = x.Roe
                                             }).ToList();

                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            EnterDate = x.EnterDate.HasValue ? x.EnterDate.Value.AddHours(5.5) : (DateTime?)null,
                            FileNumber = x.FileNumber,
                            ContainerNo = x.ContainerNo,
                            //SICutOff = x.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SICutOff.Value, sgtTimeZone) : (DateTime?)null,
                            SICutOff = x.SICutOff.HasValue ? x.SICutOff : (DateTime?)null,
                            UserId = x.UserId,
                            ActivityId = x.ActivityId,
                            StatusId = x.StatusId,
                            Comment = x.Comment,
                            Roe = x.Roe
                        }).ToList();
                    }

                    DataTable dtt = ToDataTable(fileactivtydata);

                    foreach (DataRow item in dtt.Rows)
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < dtt.Columns.Count; i++)
                        {
                            dr[i] = item[i];
                        }
                        dt.Rows.Add(dr);
                    }

                    string filename = "";
                    //filename = saveFile.FileName;
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        dt.TableName = "File Data Report";
                        var wsFileData = wb.Worksheets.Add(dt);
                        wsFileData.Columns().AdjustToContents();
                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"FileDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                        catch (Exception ex)
                        {
                        }
                    }
                }
                else if (report.ReportType == "HBL")
                {
                    dt.Columns.Add("Received Date");
                    dt.Columns.Add("File Number");
                    dt.Columns.Add("Container Number");
                    dt.Columns.Add("Booking Number");
                    dt.Columns.Add("HBL Number");
                    dt.Columns.Add("CustomerName");
                    dt.Columns.Add("User");
                    dt.Columns.Add("Activity");
                    dt.Columns.Add("Status");
                    dt.Columns.Add("Comment");
                    dt.Columns.Add("TBL");
                    dt.Columns.Add("LBL");
                    dt.Columns.Add("Total HBL");
                    if (report.DateType == "ReceivedDate")
                    {
                        HBLdata = _context.HBLActivityLog.Where(x => x.Hbl.EnterDate.Value.Date >= startDate.Date &&
                                  x.Hbl.EnterDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      EnterDate = x.Hbl.EnterDate,
                                      FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                                      ContainerNo = x.Hbl.ContainerMaster.ContainerNo,
                                      BookingNo = x.Hbl.Booking,
                                      HBLNumber = x.Hbl.HBLNumber,
                                      CustomerName = x.Hbl.CustomerName,
                                      User = x.ApplicationUser.CitrixId,
                                      Activity = x.Activity.NameOfActivity,
                                      Status = x.Status.Status,
                                      Comment = x.Comment,
                                      LBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && y.HBLNumber.StartsWith("SIN")).Count(),
                                      TBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count(),
                                      TotalHBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId).Count() != 0 ? (_context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && y.HBLNumber.StartsWith("SIN")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count()) : x.Hbl.ContainerMaster.FileMaster.TotalBL
                                  }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            EnterDate = x.EnterDate.HasValue ? x.EnterDate.Value.AddHours(5.5) : (DateTime?)null,
                            FileNumber = x.FileNumber,
                            ContainerNo = x.ContainerNo,
                            BookingNo = x.BookingNo,
                            HBLNumber = x.HBLNumber,
                            CustomerName = x.CustomerName,
                            User = x.User,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            LBL = x.LBL,
                            TBL = x.TBL,
                            TotalHBL = x.TotalHBL
                        }).ToList();
                    }
                    else if (report.DateType == "EndDate")
                    {
                        HBLdata = _context.HBLActivityLog.Where(x => x.EndDate.Value.Date >= startDate.Date &&
                                  x.EndDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      EnterDate = x.Hbl.EnterDate,
                                      FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                                      ContainerNo = x.Hbl.ContainerMaster.ContainerNo,
                                      BookingNo = x.Hbl.Booking,
                                      HBLNumber = x.Hbl.HBLNumber,
                                      CustomerName = x.Hbl.CustomerName,
                                      User = x.ApplicationUser.CitrixId,
                                      Activity = x.Activity.NameOfActivity,
                                      Status = x.Status.Status,
                                      Comment = x.Comment,
                                      LBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && y.HBLNumber.StartsWith("SIN")).Count(),
                                      TBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count(),
                                      TotalHBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId).Count() != 0 ? (_context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && y.HBLNumber.StartsWith("SIN")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count()) : x.Hbl.ContainerMaster.FileMaster.TotalBL
                                  }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            EnterDate = x.EnterDate.HasValue ? x.EnterDate.Value.AddHours(5.5) : (DateTime?)null,
                            FileNumber = x.FileNumber,
                            ContainerNo = x.ContainerNo,
                            BookingNo = x.BookingNo,
                            HBLNumber = x.HBLNumber,
                            CustomerName = x.CustomerName,
                            User = x.User,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            LBL = x.LBL,
                            TBL = x.TBL,
                            TotalHBL = x.TotalHBL
                        }).ToList();
                    }
                    else
                    {
                        HBLdata = _context.HBLActivityLog.Where(x => x.StartDate.Value.Date >= startDate.Date &&
                                   x.StartDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                   {
                                       EnterDate = x.Hbl.EnterDate,
                                       FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                                       ContainerNo = x.Hbl.ContainerMaster.ContainerNo,
                                       BookingNo = x.Hbl.Booking,
                                       HBLNumber = x.Hbl.HBLNumber,
                                       CustomerName = x.Hbl.CustomerName,
                                       User = x.ApplicationUser.CitrixId,
                                       Activity = x.Activity.NameOfActivity,
                                       Status = x.Status.Status,
                                       Comment = x.Comment,
                                       LBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && y.HBLNumber.StartsWith("SIN")).Count(),
                                       TBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count(),
                                       TotalHBL = _context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId).Count() != 0 ? (_context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && y.HBLNumber.StartsWith("SIN")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.Hbl.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count()) : x.Hbl.ContainerMaster.FileMaster.TotalBL
                                   }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            EnterDate = x.EnterDate.HasValue ? x.EnterDate.Value.AddHours(5.5) : (DateTime?)null,
                            FileNumber = x.FileNumber,
                            ContainerNo = x.ContainerNo,
                            BookingNo = x.BookingNo,
                            HBLNumber = x.HBLNumber,
                            CustomerName = x.CustomerName,
                            User = x.User,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            LBL = x.LBL,
                            TBL = x.TBL,
                            TotalHBL = x.TotalHBL
                        }).ToList();
                    }

                    DataTable dtt = ToDataTable(HBLdata);

                    foreach (DataRow item in dtt.Rows)
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < dtt.Columns.Count; i++)
                        {
                            dr[i] = item[i];
                        }
                        dt.Rows.Add(dr);
                    }

                    string filename = "";
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        dt.TableName = "HBL Data Report";
                        var wsFileData = wb.Worksheets.Add(dt);
                        wsFileData.Columns().AdjustToContents();
                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"HBLDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }

                }
                else if (report.ReportType == "UserProductionReport")
                {
                    if (report.DateType == "ReceivedDate")
                    {
                        foreach (var user in userList)
                        {
                            getFileActivityStatus = new List<FileActivityStatusList>();
                            getHBLActivityStatus = new List<HBLActivityStatusList>();
                            fileActivityList = _context.FileActivityLog.Where(x => x.ContainerMaster.FileMaster.EnterDate.Value.Date >= startDate.Date && x.ContainerMaster.FileMaster.EnterDate.Value.Date <= endDate.Date).ToList();

                            foreach (var item in fileActivitys)
                            {
                                getFileActivityStatus.Add(new FileActivityStatusList
                                {
                                    Activity = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.NameOfActivity).FirstOrDefault(),
                                    ActivityType = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.ActivityType).FirstOrDefault(),
                                    WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Query = fileActivityList.Where(x => x.StatusId == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                });
                            }

                            userActivityStatus.GetUserStatusList.Add(new UserStatusList
                            {
                                UserId = user.UserName,
                                WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.UserId == user.Id).Count(),
                                Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.UserId == user.Id).Count(),
                                Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.UserId == user.Id).Count(),
                                Query = fileActivityList.Where(x => x.StatusId == "Query" && x.UserId == user.Id).Count(),
                                CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.UserId == user.Id).Count(),
                                Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                                GetFileActivityStatus = getFileActivityStatus,
                                GetHBLActivityStatus = getHBLActivityStatus
                            });
                        }


                        var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
                        {
                            UserId = x.UserId,
                            Total = x.Total,
                            WIP = x.WIP,
                            Query = x.Query,
                            Pending = x.Pending,
                            Completed = x.Completed,
                            CompletedWithQuery = x.CompletedWithQuery,
                            GetFileActivityStatus = x.GetFileActivityStatus
                        }).ToList();

                        DataTable FileActivityStatus = ToDataTable(fileStatus);
                        dt.Columns.Add("Username");
                        dt.Columns.Add("Activity");
                        dt.Columns.Add("ActivityType");
                        dt.Columns.Add("Total");
                        dt.Columns.Add("Completed");
                        dt.Columns.Add("CompletedWithQuery");
                        dt.Columns.Add("Pending");
                        dt.Columns.Add("Query");
                        dt.Columns.Add("WIP");

                        foreach (var dr in fileStatus)
                        {
                            foreach (var file in dr.GetFileActivityStatus)
                            {
                                DataRow tr = dt.NewRow();
                                tr[0] = dr.UserId;
                                tr[0] = dr.UserId;
                                tr[1] = file.Activity;
                                tr[2] = file.ActivityType;
                                tr[3] = file.Total;
                                tr[4] = file.Completed;
                                tr[5] = file.CompletedWithQuery;
                                tr[6] = file.Pending;
                                tr[7] = file.Query;
                                tr[8] = file.WIP;
                                dt.Rows.Add(tr);
                            }
                        }

                        using (XLWorkbook wb = new XLWorkbook())
                        {
                            dt.TableName = "User Production Report";
                            var wsData = wb.Worksheets.Add(dt);
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"UserProductionReport-{DateTime.UtcNow.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                    }
                    else if (report.DateType == "EndDate")
                    {
                        foreach (var user in userList)
                        {
                            getFileActivityStatus = new List<FileActivityStatusList>();
                            getHBLActivityStatus = new List<HBLActivityStatusList>();
                            fileActivityList = _context.FileActivityLog.Where(x => x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date).ToList();

                            foreach (var item in fileActivitys)
                            {
                                getFileActivityStatus.Add(new FileActivityStatusList
                                {
                                    Activity = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.NameOfActivity).FirstOrDefault(),
                                    ActivityType = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.ActivityType).FirstOrDefault(),
                                    WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Query = fileActivityList.Where(x => x.StatusId == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                });
                            }

                            userActivityStatus.GetUserStatusList.Add(new UserStatusList
                            {
                                UserId = user.UserName,
                                WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.UserId == user.Id).Count(),
                                Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.UserId == user.Id).Count(),
                                Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.UserId == user.Id).Count(),
                                Query = fileActivityList.Where(x => x.StatusId == "Query" && x.UserId == user.Id).Count(),
                                CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.UserId == user.Id).Count(),
                                Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                                GetFileActivityStatus = getFileActivityStatus,
                                GetHBLActivityStatus = getHBLActivityStatus
                            });
                        }

                        var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
                        {
                            UserId = x.UserId,
                            Total = x.Total,
                            WIP = x.WIP,
                            Query = x.Query,
                            Pending = x.Pending,
                            Completed = x.Completed,
                            CompletedWithQuery = x.CompletedWithQuery,
                            GetFileActivityStatus = x.GetFileActivityStatus
                        }).ToList();

                        DataTable FileActivityStatus = ToDataTable(fileStatus);
                        dt.Columns.Add("User");
                        dt.Columns.Add("Activity");
                        dt.Columns.Add("ActivityType");
                        dt.Columns.Add("Total");
                        dt.Columns.Add("Completed");
                        dt.Columns.Add("CompletedWithQuery");
                        dt.Columns.Add("Pending");
                        dt.Columns.Add("Query");
                        dt.Columns.Add("WIP");

                        foreach (var dr in fileStatus)
                        {
                            foreach (var file in dr.GetFileActivityStatus)
                            {
                                DataRow tr = dt.NewRow();
                                tr[0] = dr.UserId;
                                tr[0] = dr.UserId;
                                tr[1] = file.Activity;
                                tr[2] = file.ActivityType;
                                tr[3] = file.Total;
                                tr[4] = file.Completed;
                                tr[5] = file.CompletedWithQuery;
                                tr[6] = file.Pending;
                                tr[7] = file.Query;
                                tr[8] = file.WIP;
                                dt.Rows.Add(tr);
                            }
                        }

                        using (XLWorkbook wb = new XLWorkbook())
                        {
                            dt.TableName = "User Production Report";
                            var wsData = wb.Worksheets.Add(dt);
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"UserProductionReport-{DateTime.UtcNow.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                    }
                    else
                    {
                        foreach (var user in userList)
                        {
                            getFileActivityStatus = new List<FileActivityStatusList>();
                            getHBLActivityStatus = new List<HBLActivityStatusList>();
                            fileActivityList = _context.FileActivityLog.Where(x => x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date).ToList();

                            foreach (var item in fileActivitys)
                            {
                                getFileActivityStatus.Add(new FileActivityStatusList
                                {
                                    Activity = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.NameOfActivity).FirstOrDefault(),
                                    ActivityType = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.ActivityType).FirstOrDefault(),
                                    WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Query = fileActivityList.Where(x => x.StatusId == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                    Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                                });
                            }

                            userActivityStatus.GetUserStatusList.Add(new UserStatusList
                            {
                                UserId = user.UserName,
                                WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.UserId == user.Id).Count(),
                                Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.UserId == user.Id).Count(),
                                Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.UserId == user.Id).Count(),
                                Query = fileActivityList.Where(x => x.StatusId == "Query" && x.UserId == user.Id).Count(),
                                CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.UserId == user.Id).Count(),
                                Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                                GetFileActivityStatus = getFileActivityStatus,
                                GetHBLActivityStatus = getHBLActivityStatus
                            });
                        }

                        var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
                        {
                            UserId = x.UserId,
                            Total = x.Total,
                            WIP = x.WIP,
                            Query = x.Query,
                            Pending = x.Pending,
                            Completed = x.Completed,
                            CompletedWithQuery = x.CompletedWithQuery,
                            GetFileActivityStatus = x.GetFileActivityStatus
                        }).ToList();

                        DataTable FileActivityStatus = ToDataTable(fileStatus);
                        dt.Columns.Add("User");
                        dt.Columns.Add("Activity");
                        dt.Columns.Add("ActivityType");
                        dt.Columns.Add("Total");
                        dt.Columns.Add("Completed");
                        dt.Columns.Add("CompletedWithQuery");
                        dt.Columns.Add("Pending");
                        dt.Columns.Add("Query");
                        dt.Columns.Add("WIP");

                        foreach (var dr in fileStatus)
                        {
                            foreach (var file in dr.GetFileActivityStatus)
                            {
                                DataRow tr = dt.NewRow();
                                tr[0] = dr.UserId;
                                tr[0] = dr.UserId;
                                tr[1] = file.Activity;
                                tr[2] = file.ActivityType;
                                tr[3] = file.Total;
                                tr[4] = file.Completed;
                                tr[5] = file.CompletedWithQuery;
                                tr[6] = file.Pending;
                                tr[7] = file.Query;
                                tr[8] = file.WIP;
                                dt.Rows.Add(tr);
                            }
                        }

                        using (XLWorkbook wb = new XLWorkbook())
                        {
                            dt.TableName = "User Production Report";
                            var wsData = wb.Worksheets.Add(dt);
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"UserProductionReport-{DateTime.UtcNow.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                    }
                }
                else if (report.ReportType == "ActivityWiseUserHBLProduction")
                {
                    if (report.DateType == "ReceivedDate")
                    {
                        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                        ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
                        ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
                        var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        List<StatusMaster> _status = _context.StatusMaster.ToList();
                        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                        var data = _context.HBLActivityLog.Where(x => x.Hbl.ContainerMaster.FileMaster.EnterDate.Value.Date >= startDate.Date && x.Hbl.ContainerMaster.FileMaster.EnterDate.Value.Date <= endDate.Date).Include(x => x.Hbl.ContainerMaster).GroupBy(x => new
                        {
                            x.ApplicationUser.CitrixId,
                        }).Select(x => new UserDashboardViewModel
                        {
                            User = x.Key.CitrixId,
                            Count = x.Count(),
                        }).ToList();

                        foreach (UserDashboardViewModel dashboard in data)
                        {
                            dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.Hbl.ContainerMaster.FileMaster.EnterDate.Value.Date >= startDate.Date && x.Hbl.ContainerMaster.FileMaster.EnterDate.Value.Date <= endDate.Date).Include(x => x.Hbl.ContainerMaster).Include(x => x.Activity)
                            .GroupBy(x => new
                            {
                                x.Activity.Id,
                                x.StatusId,
                            }).Select(x => new HBLCount
                            {
                                Count = x.Count(),
                                Status = x.Key.StatusId,
                                ActivityId = x.Key.Id,
                            }).ToList();

                            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                            {
                                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completedWithQuery)).Sum(x => x.Count);

                                dashboard.HBLStatusCount.Add(new HBLStatusCount
                                {
                                    Completed = dashboard.Completed,
                                    Pending = dashboard.Pending,
                                    Query = dashboard.Query,
                                    WIP = dashboard.WIP,
                                    CompletedWithQuery = dashboard.CompletedWithQuery
                                });
                                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                                dashboard.TotalPending += dashboard.Pending;
                                dashboard.TotalQuery += dashboard.Query;
                                dashboard.TotalWIP += dashboard.WIP;
                                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                            }
                        }

                        var overallTotal = new UserDashboardViewModel
                        {
                            User = "Total",
                            Count = data.Sum(x => x.Count),
                            TotalCompleted = data.Sum(x => x.TotalCompleted),
                            TotalPending = data.Sum(x => x.TotalPending),
                            TotalQuery = data.Sum(x => x.TotalQuery),
                            TotalWIP = data.Sum(x => x.TotalWIP),
                            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                        };

                        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                        {
                            var activityTotal = new HBLStatusCount
                            {
                                ActivityId = activityMaster.Id,
                                Completed = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
                                    .Sum(c => c.Count)),
                                Pending = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
                                    .Sum(c => c.Count)),
                                Query = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
                                    .Sum(c => c.Count)),
                                WIP = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
                                    .Sum(c => c.Count)),
                                CompletedWithQuery = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completedWithQuery))
                                    .Sum(c => c.Count))
                            };
                            overallTotal.HBLStatusCount.Add(activityTotal);
                        }

                        data.Add(overallTotal);
                        userdashboardModel.AddRange(data);

                        // Create a new workbook
                        using (var workbook = new XLWorkbook())
                        {
                            var worksheet = workbook.Worksheets.Add("UserActivity");

                            // Add headers to the worksheet
                            worksheet.Cell(1, 1).Value = "User Name";
                            worksheet.Cell(1, 2).Value = "Total";
                            worksheet.Cell(1, 3).Value = "Completed";
                            worksheet.Cell(1, 4).Value = "Pending";
                            worksheet.Cell(1, 5).Value = "Query";
                            worksheet.Cell(1, 6).Value = "WIP";
                            int colIndex = 7;

                            // Add headers for each activity
                            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                            {
                                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                                colIndex += 4;
                            }

                            // Populate data in the worksheet
                            int rowIndex = 2;
                            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                            {
                                worksheet.Cell(rowIndex, 1).Value = d.User;
                                worksheet.Cell(rowIndex, 2).Value = d.Count;
                                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;
                                colIndex = 7;
                                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                                {
                                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                                    colIndex += 4;
                                }

                                rowIndex++;
                            }

                            // Create a memory stream to store the Excel file
                            using (MemoryStream stream = new MemoryStream())
                            {
                                workbook.SaveAs(stream);
                                string excelname = $"ActivityWiseUserHBLProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }

                    }
                    else if (report.DateType == "EndDate")
                    {
                        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                        ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
                        ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
                        var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        List<StatusMaster> _status = _context.StatusMaster.ToList();
                        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                        var data = _context.HBLActivityLog.Where(x => x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date).Include(x => x.Hbl.ContainerMaster).GroupBy(x => new
                        {
                            x.ApplicationUser.CitrixId,
                        }).Select(x => new UserDashboardViewModel
                        {
                            User = x.Key.CitrixId,
                            Count = x.Count(),
                        }).ToList();

                        foreach (UserDashboardViewModel dashboard in data)
                        {
                            dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date).Include(x => x.Hbl).Include(x => x.Activity)
                            .GroupBy(x => new
                            {
                                x.Activity.Id,
                                x.StatusId,
                            }).Select(x => new HBLCount
                            {
                                Count = x.Count(),
                                Status = x.Key.StatusId,
                                ActivityId = x.Key.Id,
                            }).ToList();

                            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                            {
                                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completedWithQuery)).Sum(x => x.Count);

                                dashboard.HBLStatusCount.Add(new HBLStatusCount
                                {
                                    Completed = dashboard.Completed,
                                    Pending = dashboard.Pending,
                                    Query = dashboard.Query,
                                    WIP = dashboard.WIP,
                                    CompletedWithQuery = dashboard.CompletedWithQuery
                                });
                                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                                dashboard.TotalPending += dashboard.Pending;
                                dashboard.TotalQuery += dashboard.Query;
                                dashboard.TotalWIP += dashboard.WIP;
                                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                            }
                        }

                        var overallTotal = new UserDashboardViewModel
                        {
                            User = "Total",
                            Count = data.Sum(x => x.Count),
                            TotalCompleted = data.Sum(x => x.TotalCompleted),
                            TotalPending = data.Sum(x => x.TotalPending),
                            TotalQuery = data.Sum(x => x.TotalQuery),
                            TotalWIP = data.Sum(x => x.TotalWIP),
                            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                        };

                        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                        {
                            var activityTotal = new HBLStatusCount
                            {
                                ActivityId = activityMaster.Id,
                                Completed = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
                                    .Sum(c => c.Count)),
                                Pending = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
                                    .Sum(c => c.Count)),
                                Query = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
                                    .Sum(c => c.Count)),
                                WIP = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
                                    .Sum(c => c.Count)),
                                CompletedWithQuery = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completedWithQuery))
                                    .Sum(c => c.Count))
                            };
                            overallTotal.HBLStatusCount.Add(activityTotal);
                        }

                        data.Add(overallTotal);
                        userdashboardModel.AddRange(data);

                        // Create a new workbook
                        using (var workbook = new XLWorkbook())
                        {
                            var worksheet = workbook.Worksheets.Add("UserActivity");

                            // Add headers to the worksheet
                            worksheet.Cell(1, 1).Value = "User Name";
                            worksheet.Cell(1, 2).Value = "Total";
                            worksheet.Cell(1, 3).Value = "Completed";
                            worksheet.Cell(1, 4).Value = "Pending";
                            worksheet.Cell(1, 5).Value = "Query";
                            worksheet.Cell(1, 6).Value = "WIP";
                            int colIndex = 7;

                            // Add headers for each activity
                            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                            {
                                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                                colIndex += 4;
                            }

                            // Populate data in the worksheet
                            int rowIndex = 2;
                            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                            {
                                worksheet.Cell(rowIndex, 1).Value = d.User;
                                worksheet.Cell(rowIndex, 2).Value = d.Count;
                                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;
                                colIndex = 7;
                                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                                {
                                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                                    colIndex += 4;
                                }

                                rowIndex++;
                            }

                            // Create a memory stream to store the Excel file
                            using (MemoryStream stream = new MemoryStream())
                            {
                                workbook.SaveAs(stream);
                                string excelname = $"ActivityWiseUserHBLProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                    }
                    else
                    {

                        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                        ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
                        ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
                        var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        List<StatusMaster> _status = _context.StatusMaster.ToList();
                        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                        var data = _context.HBLActivityLog.Where(x => x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date).Include(x => x.Hbl.ContainerMaster).GroupBy(x => new
                        {
                            x.ApplicationUser.CitrixId,
                        }).Select(x => new UserDashboardViewModel
                        {
                            User = x.Key.CitrixId,
                            Count = x.Count(),
                        }).ToList();

                        foreach (UserDashboardViewModel dashboard in data)
                        {
                            dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date).Include(x => x.Hbl).Include(x => x.Activity)
                            .GroupBy(x => new
                            {
                                x.Activity.Id,
                                x.StatusId,
                            }).Select(x => new HBLCount
                            {
                                Count = x.Count(),
                                Status = x.Key.StatusId,
                                ActivityId = x.Key.Id,
                            }).ToList();

                            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                            {
                                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completedWithQuery)).Sum(x => x.Count);

                                dashboard.HBLStatusCount.Add(new HBLStatusCount
                                {
                                    Completed = dashboard.Completed,
                                    Pending = dashboard.Pending,
                                    Query = dashboard.Query,
                                    WIP = dashboard.WIP,
                                    CompletedWithQuery = dashboard.CompletedWithQuery
                                });
                                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                                dashboard.TotalPending += dashboard.Pending;
                                dashboard.TotalQuery += dashboard.Query;
                                dashboard.TotalWIP += dashboard.WIP;
                                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                            }
                        }

                        var overallTotal = new UserDashboardViewModel
                        {
                            User = "Total",
                            Count = data.Sum(x => x.Count),
                            TotalCompleted = data.Sum(x => x.TotalCompleted),
                            TotalPending = data.Sum(x => x.TotalPending),
                            TotalQuery = data.Sum(x => x.TotalQuery),
                            TotalWIP = data.Sum(x => x.TotalWIP),
                            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                        };

                        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                        {
                            var activityTotal = new HBLStatusCount
                            {
                                ActivityId = activityMaster.Id,
                                Completed = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
                                    .Sum(c => c.Count)),
                                Pending = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
                                    .Sum(c => c.Count)),
                                Query = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
                                    .Sum(c => c.Count)),
                                WIP = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
                                    .Sum(c => c.Count)),
                                CompletedWithQuery = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completedWithQuery))
                                    .Sum(c => c.Count))
                            };
                            overallTotal.HBLStatusCount.Add(activityTotal);
                        }

                        data.Add(overallTotal);
                        userdashboardModel.AddRange(data);

                        // Create a new workbook
                        using (var workbook = new XLWorkbook())
                        {
                            var worksheet = workbook.Worksheets.Add("UserActivity");

                            // Add headers to the worksheet
                            worksheet.Cell(1, 1).Value = "User Name";
                            worksheet.Cell(1, 2).Value = "Total";
                            worksheet.Cell(1, 3).Value = "Completed";
                            worksheet.Cell(1, 4).Value = "Pending";
                            worksheet.Cell(1, 5).Value = "Query";
                            worksheet.Cell(1, 6).Value = "WIP";
                            int colIndex = 7;

                            // Add headers for each activity
                            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL"))
                            {
                                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                                colIndex += 4;
                            }

                            // Populate data in the worksheet
                            int rowIndex = 2;
                            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                            {
                                worksheet.Cell(rowIndex, 1).Value = d.User;
                                worksheet.Cell(rowIndex, 2).Value = d.Count;
                                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;
                                colIndex = 7;
                                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                                {
                                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                                    colIndex += 4;
                                }

                                rowIndex++;
                            }

                            // Create a memory stream to store the Excel file
                            using (MemoryStream stream = new MemoryStream())
                            {
                                workbook.SaveAs(stream);
                                string excelname = $"ActivityWiseUserHBLProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }

                    }

                }
                else if (report.ReportType == "ActivityWiseUserFileProduction")
                {
                    if (report.DateType == "ReceivedDate")
                    {
                        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                        ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
                        ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
                        var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        List<StatusMaster> _status = _context.StatusMaster.ToList();
                        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                        var data = _context.FileActivityLog.Where(x => x.ContainerMaster.FileMaster.EnterDate.Value.Date >= startDate.Date && x.ContainerMaster.FileMaster.EnterDate.Value.Date <= endDate.Date).Include(x => x.ContainerMaster).GroupBy(x => new
                        {
                            x.ApplicationUser.CitrixId,
                        }).Select(x => new UserDashboardViewModel
                        {
                            User = x.Key.CitrixId,
                            Count = x.Count(),
                        }).ToList();

                        foreach (UserDashboardViewModel dashboard in data)
                        {
                            dashboard.HBLCount = _context.FileActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.ContainerMaster.FileMaster.EnterDate.Value.Date >= startDate.Date && x.ContainerMaster.FileMaster.EnterDate.Value.Date <= endDate.Date).Include(x => x.ContainerMaster).Include(x => x.Activity)
                            .GroupBy(x => new
                            {
                                x.Activity.Id,
                                x.StatusId,
                            }).Select(x => new HBLCount
                            {
                                Count = x.Count(),
                                Status = x.Key.StatusId,
                                ActivityId = x.Key.Id,
                            }).ToList();

                            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                            {
                                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completedWithQuery).Sum(x => x.Count);

                                dashboard.HBLStatusCount.Add(new HBLStatusCount
                                {
                                    Completed = dashboard.Completed,
                                    Pending = dashboard.Pending,
                                    Query = dashboard.Query,
                                    WIP = dashboard.WIP,
                                    CompletedWithQuery = dashboard.CompletedWithQuery
                                });
                                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                                dashboard.TotalPending += dashboard.Pending;
                                dashboard.TotalQuery += dashboard.Query;
                                dashboard.TotalWIP += dashboard.WIP;
                                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                            }
                        }

                        var overallTotal = new UserDashboardViewModel
                        {
                            User = "Total",
                            Count = data.Sum(x => x.Count),
                            TotalCompleted = data.Sum(x => x.TotalCompleted),
                            TotalPending = data.Sum(x => x.TotalPending),
                            TotalQuery = data.Sum(x => x.TotalQuery),
                            TotalWIP = data.Sum(x => x.TotalWIP),
                            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                        };

                        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                        {
                            var activityTotal = new HBLStatusCount
                            {
                                ActivityId = activityMaster.Id,
                                Completed = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completed)
                                    .Sum(c => c.Count)),
                                Pending = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == pending)
                                    .Sum(c => c.Count)),
                                Query = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == query)
                                    .Sum(c => c.Count)),
                                WIP = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == wip)
                                    .Sum(c => c.Count)),
                                CompletedWithQuery = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completedWithQuery)
                                    .Sum(c => c.Count))
                            };
                            overallTotal.HBLStatusCount.Add(activityTotal);
                        }

                        data.Add(overallTotal);
                        userdashboardModel.AddRange(data);

                        // Create a new workbook
                        using (var workbook = new XLWorkbook())
                        {
                            var worksheet = workbook.Worksheets.Add("UserActivity");

                            // Add headers to the worksheet
                            worksheet.Cell(1, 1).Value = "User Name";
                            worksheet.Cell(1, 2).Value = "Total";
                            worksheet.Cell(1, 3).Value = "Completed";
                            worksheet.Cell(1, 4).Value = "Pending";
                            worksheet.Cell(1, 5).Value = "Query";
                            worksheet.Cell(1, 6).Value = "WIP";
                            int colIndex = 7;

                            // Add headers for each activity
                            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                            {
                                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                                colIndex += 4;
                            }

                            // Populate data in the worksheet
                            int rowIndex = 2;
                            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                            {
                                worksheet.Cell(rowIndex, 1).Value = d.User;
                                worksheet.Cell(rowIndex, 2).Value = d.Count;
                                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;
                                colIndex = 7;
                                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                                {
                                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                                    colIndex += 4;
                                }

                                rowIndex++;
                            }

                            // Create a memory stream to store the Excel file
                            using (MemoryStream stream = new MemoryStream())
                            {
                                workbook.SaveAs(stream);
                                string excelname = $"ActivityWiseUserFileProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }

                    }
                    else if (report.DateType == "EndDate")
                    {
                        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                        ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
                        ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
                        var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        List<StatusMaster> _status = _context.StatusMaster.ToList();
                        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                        var data = _context.FileActivityLog.Where(x => x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date).Include(x => x.ContainerMaster).GroupBy(x => new
                        {
                            x.ApplicationUser.CitrixId,
                        }).Select(x => new UserDashboardViewModel
                        {
                            User = x.Key.CitrixId,
                            Count = x.Count(),
                        }).ToList();

                        foreach (UserDashboardViewModel dashboard in data)
                        {
                            dashboard.HBLCount = _context.FileActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.EndDate.Value.Date >= startDate.Date && x.EndDate.Value.Date <= endDate.Date).Include(x => x.ContainerMaster).Include(x => x.Activity)
                            .GroupBy(x => new
                            {
                                x.Activity.Id,
                                x.StatusId,
                            }).Select(x => new HBLCount
                            {
                                Count = x.Count(),
                                Status = x.Key.StatusId,
                                ActivityId = x.Key.Id,
                            }).ToList();

                            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                            {
                                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completedWithQuery).Sum(x => x.Count);

                                dashboard.HBLStatusCount.Add(new HBLStatusCount
                                {
                                    Completed = dashboard.Completed,
                                    Pending = dashboard.Pending,
                                    Query = dashboard.Query,
                                    WIP = dashboard.WIP,
                                    CompletedWithQuery = dashboard.CompletedWithQuery
                                });
                                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                                dashboard.TotalPending += dashboard.Pending;
                                dashboard.TotalQuery += dashboard.Query;
                                dashboard.TotalWIP += dashboard.WIP;
                                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                            }
                        }

                        var overallTotal = new UserDashboardViewModel
                        {
                            User = "Total",
                            Count = data.Sum(x => x.Count),
                            TotalCompleted = data.Sum(x => x.TotalCompleted),
                            TotalPending = data.Sum(x => x.TotalPending),
                            TotalQuery = data.Sum(x => x.TotalQuery),
                            TotalWIP = data.Sum(x => x.TotalWIP),
                            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                        };

                        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                        {
                            var activityTotal = new HBLStatusCount
                            {
                                ActivityId = activityMaster.Id,
                                Completed = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completed)
                                    .Sum(c => c.Count)),
                                Pending = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == pending)
                                    .Sum(c => c.Count)),
                                Query = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == query)
                                    .Sum(c => c.Count)),
                                WIP = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == wip)
                                    .Sum(c => c.Count)),
                                CompletedWithQuery = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completedWithQuery)
                                    .Sum(c => c.Count))
                            };
                            overallTotal.HBLStatusCount.Add(activityTotal);
                        }

                        data.Add(overallTotal);
                        userdashboardModel.AddRange(data);

                        // Create a new workbook
                        using (var workbook = new XLWorkbook())
                        {
                            var worksheet = workbook.Worksheets.Add("UserActivity");

                            // Add headers to the worksheet
                            worksheet.Cell(1, 1).Value = "User Name";
                            worksheet.Cell(1, 2).Value = "Total";
                            worksheet.Cell(1, 3).Value = "Completed";
                            worksheet.Cell(1, 4).Value = "Pending";
                            worksheet.Cell(1, 5).Value = "Query";
                            worksheet.Cell(1, 6).Value = "WIP";
                            int colIndex = 7;

                            // Add headers for each activity
                            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                            {
                                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                                colIndex += 4;
                            }

                            // Populate data in the worksheet
                            int rowIndex = 2;
                            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                            {
                                worksheet.Cell(rowIndex, 1).Value = d.User;
                                worksheet.Cell(rowIndex, 2).Value = d.Count;
                                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;

                                colIndex = 7;
                                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                                {
                                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                                    colIndex += 4;
                                }

                                rowIndex++;
                            }

                            // Create a memory stream to store the Excel file
                            using (MemoryStream stream = new MemoryStream())
                            {
                                workbook.SaveAs(stream);
                                string excelname = $"ActivityWiseUserFileProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                    }
                    else
                    {

                        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                        ViewData["Activity"] = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        ViewData["User"] = _context.Users.OrderBy(x => x.CitrixId).ToList();
                        ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
                        var activityList = _context.ActivityMaster.OrderBy(x => x.Id).ToList();
                        List<StatusMaster> _status = _context.StatusMaster.ToList();
                        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                        var data = _context.FileActivityLog.Where(x => x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date).Include(x => x.ContainerMaster).GroupBy(x => new
                        {
                            x.ApplicationUser.CitrixId,
                        }).Select(x => new UserDashboardViewModel
                        {
                            User = x.Key.CitrixId,
                            Count = x.Count(),
                        }).ToList();

                        foreach (UserDashboardViewModel dashboard in data)
                        {
                            dashboard.HBLCount = _context.FileActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.StartDate.Value.Date >= startDate.Date && x.StartDate.Value.Date <= endDate.Date).Include(x => x.ContainerMaster).Include(x => x.Activity)
                            .GroupBy(x => new
                            {
                                x.Activity.Id,
                                x.StatusId,
                            }).Select(x => new HBLCount
                            {
                                Count = x.Count(),
                                Status = x.Key.StatusId,
                                ActivityId = x.Key.Id,
                            }).ToList();

                            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                            {
                                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completedWithQuery).Sum(x => x.Count);

                                dashboard.HBLStatusCount.Add(new HBLStatusCount
                                {
                                    Completed = dashboard.Completed,
                                    Pending = dashboard.Pending,
                                    Query = dashboard.Query,
                                    WIP = dashboard.WIP,
                                    CompletedWithQuery = dashboard.CompletedWithQuery
                                });
                                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                                dashboard.TotalPending += dashboard.Pending;
                                dashboard.TotalQuery += dashboard.Query;
                                dashboard.TotalWIP += dashboard.WIP;
                                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                            }
                        }

                        var overallTotal = new UserDashboardViewModel
                        {
                            User = "Total",
                            Count = data.Sum(x => x.Count),
                            TotalCompleted = data.Sum(x => x.TotalCompleted),
                            TotalPending = data.Sum(x => x.TotalPending),
                            TotalQuery = data.Sum(x => x.TotalQuery),
                            TotalWIP = data.Sum(x => x.TotalWIP),
                            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                        };

                        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                        {
                            var activityTotal = new HBLStatusCount
                            {
                                ActivityId = activityMaster.Id,
                                Completed = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completed)
                                    .Sum(c => c.Count)),
                                Pending = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == pending)
                                    .Sum(c => c.Count)),
                                Query = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == query)
                                    .Sum(c => c.Count)),
                                WIP = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == wip)
                                    .Sum(c => c.Count)),
                                CompletedWithQuery = data.Sum(x => x.HBLCount
                                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completedWithQuery)
                                    .Sum(c => c.Count))
                            };
                            overallTotal.HBLStatusCount.Add(activityTotal);
                        }

                        data.Add(overallTotal);
                        userdashboardModel.AddRange(data);

                        // Create a new workbook
                        using (var workbook = new XLWorkbook())
                        {
                            var worksheet = workbook.Worksheets.Add("UserActivity");

                            // Add headers to the worksheet
                            worksheet.Cell(1, 1).Value = "User Name";
                            worksheet.Cell(1, 2).Value = "Total";
                            worksheet.Cell(1, 3).Value = "Completed";
                            worksheet.Cell(1, 4).Value = "Pending";
                            worksheet.Cell(1, 5).Value = "Query";
                            worksheet.Cell(1, 6).Value = "WIP";
                            int colIndex = 7;

                            // Add headers for each activity
                            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.ActivityType == "File"))
                            {
                                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                                colIndex += 4;
                            }

                            // Populate data in the worksheet
                            int rowIndex = 2;
                            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                            {
                                worksheet.Cell(rowIndex, 1).Value = d.User;
                                worksheet.Cell(rowIndex, 2).Value = d.Count;
                                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;
                                colIndex = 7;
                                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                                {
                                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                                    colIndex += 4;
                                }

                                rowIndex++;
                            }

                            // Create a memory stream to store the Excel file
                            using (MemoryStream stream = new MemoryStream())
                            {
                                workbook.SaveAs(stream);
                                string excelname = $"ActivityWiseUserFileProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                    }
                }
            }
            else
            {
                ViewBag.ErrorMessage = "Please Select Date";
            }

            return View();
        }

        //List to Database convert
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        //Get UserCount
        public ActionResult GetCountofUser()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetHblActivityDataList(string hblId)
        {
            ViewData["hblActivityList"] = _context.HBLActivityLog.Include(x => x.Hbl).Where(x => x.HBLId == hblId).Select(x => new HBLActivityLogsListViewModel
            {
                Id = x.Id,
                HBLNumber = x.Hbl.HBLNumber == null ? "" : x.Hbl.HBLNumber,
                Activity = x.Activity.NameOfActivity,
                StartDate = x.StartDate.Value.AddHours(5.5),
                EndDate = x.EndDate.Value.AddHours(5.5),
                Status = x.Status.Status,
                Comment = x.Comment == null ? "" : x.Comment,
                User = x.ApplicationUser.CitrixId == null ? "" : x.ApplicationUser.CitrixId
            }).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivityDataList(string hblno, string hbl)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Where(x => x.Hbl.HBLNumber == hblno).ToList();
            List<HBLActivityLogsListViewModel> hblActivityLog = new List<HBLActivityLogsListViewModel>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityLogsListViewModel
                {
                    Id = item.Id,
                    HBLNumber = hblno == null ? "" : hblno,
                    Activity = item.Activity.NameOfActivity == null ? "" : item.Activity.NameOfActivity,
                    StartDate = item.StartDate.Value.AddHours(5.5),
                    EndDate = item.EndDate.Value.AddHours(5.5),
                    Status = item.Status.Status,
                    User = item.ApplicationUser.CitrixId,
                    Comment = item.Comment,
                });
            }
            return Json(hblActivityLog);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult FileAllocation(string[] fileNumbers, string activity, string user, string status)
        {
            try
            {
                if (fileNumbers.Length == 0)
                {
                    return Json("Please select file checkbox");
                }
                else if (activity == null)
                {
                    return Json("Please select activities");
                }
                else if (user == null)
                {
                    return Json("Please select user");
                }
                else
                {
                    var compstatusId = _context.StatusMaster.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                    var statusId = _context.StatusMaster.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                    var completedwithquery = _context.StatusMaster.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();
                    var carrierRequest = _context.ActivityMaster.Where(x => x.NameOfActivity == "Carrier Request").Select(x => x.Id).FirstOrDefault();
                    var tblProcessing = _context.ActivityMaster.Where(x => x.NameOfActivity == "TBL Processing").Select(x => x.Id).FirstOrDefault();
                    var siToCarrier = _context.ActivityMaster.Where(x => x.NameOfActivity == "SI To Carrier").Select(x => x.Id).FirstOrDefault();
                    var blRequest = _context.ActivityMaster.Where(x => x.NameOfActivity == "BL Request" && x.ActivityType == "File").Select(x => x.Id).FirstOrDefault();
                    var tallySheet = _context.ActivityMaster.Where(x => x.NameOfActivity == "Tally Sheet").Select(x => x.Id).FirstOrDefault();
                    var mblReview = _context.ActivityMaster.Where(x => x.NameOfActivity == "MBL Review").Select(x => x.Id).FirstOrDefault();
                    var finalBL = _context.ActivityMaster.Where(x => x.NameOfActivity == "Final BL").Select(x => x.Id).FirstOrDefault();
                    var preAlert = _context.ActivityMaster.Where(x => x.NameOfActivity == "Pre-Alert").Select(x => x.Id).FirstOrDefault();
                    var permit = _context.ActivityMaster.Where(x => x.NameOfActivity == "Permit").Select(x => x.Id).FirstOrDefault();
                    var invoices = _context.ActivityMaster.Where(x => x.NameOfActivity == "Invoices To POD Agent").Select(x => x.Id).FirstOrDefault();
                    string msg = "";
                    foreach (string fileid in fileNumbers)
                    {
                        var fileactivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == fileid && x.ActivityId == activity).FirstOrDefault();
                        var activityMaster = _context.ActivityMaster.Where(x => x.Id == activity).FirstOrDefault();
                        var incompleteActivities = _context.FileActivityLog
                                                    .Include(x => x.Activity)
                                                    .Include(x => x.Status)
                                                    .Where(x => x.ContainerId == fileid
                                                                && x.Activity.FileSequence < activityMaster.FileSequence
                                                                && x.Status.Status != "Completed") // Adjust "Completed" to match your status name
                                                    .OrderBy(x => x.Activity.FileSequence)
                                                    .FirstOrDefault();
                        var fileactivityLast = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == fileid && x.Activity.FileSequence == incompleteActivities.Activity.FileSequence).FirstOrDefault();
                        var lastFileActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == fileid && x.Activity.FileSequence == fileactivityLast.Activity.FileSequence).FirstOrDefault() == null ? _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == fileid && x.ActivityId == incompleteActivities.Activity.Id && x.StatusId != compstatusId).FirstOrDefault() : _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == fileid && x.Activity.FileSequence == fileactivityLast.Activity.FileSequence).FirstOrDefault();
                        if (fileactivity == null)
                        {
                            fileactivityLast = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == fileid && x.Activity.FileSequence < activityMaster.FileSequence).FirstOrDefault();
                            return Json(new { message = $"Complete {lastFileActivity.Activity.NameOfActivity} file activity first." });
                        }
                        if (fileactivity != null)
                        {
                            if (fileactivity.StatusId == compstatusId)
                            {
                                return Json("File activity status is completed so does not allocate");
                            }
                            else if(lastFileActivity.StatusId != compstatusId && lastFileActivity.ActivityId != carrierRequest)
                            {
                                return Json(new { message = $"Complete {lastFileActivity.Activity.NameOfActivity} file activity first." });
                            }
                            else if (fileactivity.ActivityId == siToCarrier)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == blRequest && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == blRequest && fileactivities.StatusId == compstatusId)
                                {

                                    fileactivity.UserId = user;
                                    fileactivity.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivity);
                                    _context.SaveChanges();

                                }
                                else if (fileactivities.ActivityId == blRequest && fileactivities.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected BL Request activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == blRequest)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == carrierRequest && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == carrierRequest && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivity.UserId = user;
                                    fileactivity.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivity);
                                    _context.SaveChanges();
                                }
                                else if (fileactivities.ActivityId == carrierRequest && fileactivities.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Carrier Request activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == finalBL)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == siToCarrier && x.StatusId == compstatusId).FirstOrDefault();

                                if ((fileactivities.ActivityId == siToCarrier && fileactivities.StatusId == compstatusId))
                                {
                                    fileactivity.UserId = user;
                                    fileactivity.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivity);
                                    _context.SaveChanges();
                                }
                                else if (fileactivity.ActivityId == siToCarrier && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected SI To Carrier activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == preAlert)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == finalBL && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == finalBL && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivity.UserId = user;
                                    fileactivity.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivity);
                                    _context.SaveChanges();
                                }
                                else if (fileactivity.ActivityId == finalBL && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Final BL activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == permit)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == preAlert && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == preAlert && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivity.UserId = user;
                                    fileactivity.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivity);
                                    _context.SaveChanges();
                                }
                                else if (fileactivity.ActivityId == preAlert && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Pre-Alert activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == invoices)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == permit && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == permit && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivity.UserId = user;
                                    fileactivity.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivity);
                                    _context.SaveChanges();
                                }
                                else if (fileactivity.ActivityId == permit && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Invoices To POD Agent activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else
                            {
                                fileactivity.UserId = user;
                                fileactivity.StatusId = statusId;
                                _context.FileActivityLog.Update(fileactivity);
                                _context.SaveChanges();
                            }
                        }
                        else
                        {
                            FileActivityLog fileActivitylog = new FileActivityLog
                            {
                                ContainerId = fileid,
                                ActivityId = activity,
                                StatusId = statusId,
                                UserId = user,
                                Comment = null,
                                StartDate = null,
                                EndDate = null,
                            };
                            _context.FileActivityLog.Add(fileActivitylog);
                            _context.SaveChanges();
                            var fileactivityList = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == activity).FirstOrDefault();
                            if (fileactivityList.StatusId == compstatusId)
                            {
                                return Json("File activity status is completed so does not allocate");
                            }
                            else if (fileactivityList.ActivityId == siToCarrier)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == blRequest && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == blRequest && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                                else if (fileactivityList.ActivityId == carrierRequest && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected BL Request activity.");
                                }
                                else
                                {

                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else if (fileactivityList.ActivityId == blRequest)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == carrierRequest && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == carrierRequest && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                                else if (fileactivityList.ActivityId == carrierRequest && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Carrier Request activity.");
                                }
                                else
                                {

                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else if (fileactivityList.ActivityId == finalBL)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == siToCarrier && x.StatusId == compstatusId).FirstOrDefault();

                                if ((fileactivities.ActivityId == siToCarrier && fileactivities.StatusId == compstatusId))
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                                else if (fileactivityList.ActivityId == siToCarrier && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected SI To Carrier activity.");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }

                            }
                            else if (fileactivityList.ActivityId == preAlert)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == finalBL && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == finalBL && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                                else if (fileactivityList.ActivityId == finalBL && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Final BL activity.");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else if (fileactivityList.ActivityId == permit)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == preAlert && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == preAlert && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                                else if (fileactivityList.ActivityId == preAlert && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Pre-Alert activity.");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else if (fileactivityList.ActivityId == invoices)
                            {
                                var fileactivities = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == permit && x.StatusId == compstatusId).FirstOrDefault();

                                if (fileactivities.ActivityId == permit && fileactivities.StatusId == compstatusId)
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                                else if (fileactivityList.ActivityId == permit && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Invoices To POD Agent activity.");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else
                            {
                                fileactivityList.UserId = user;
                                fileactivityList.StatusId = statusId;
                                _context.FileActivityLog.Update(fileactivityList);
                                _context.SaveChanges();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("error");
            }

            _context.SaveChanges();
            return Json("Success");
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public JsonResult UpdateData(string? columnName, string? editedValue, string? containerId, string? fileId, string? fileActivityLogId, string? startDateTime)
        {
            var fileLog = _context.FileActivityLog.Include(x => x.ContainerMaster).ThenInclude(x => x.FileMaster).Where(x => x.Id == fileActivityLogId && x.ContainerId == containerId).FirstOrDefault();
            var fileList = _context.FileMaster.ToList();
            var containerList = _context.ContainerMaster.ToList();
            DateTime date = Convert.ToDateTime(startDateTime).ToUniversalTime();

            if (fileLog != null)
            {
                _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                {
                    FileLogId = fileActivityLogId,
                    ActivityId = fileLog.ActivityId,
                    StatusId = fileLog.StatusId,
                    UserId = fileLog.UserId,
                    StartDate = fileLog.StartDate,
                    EndDate = fileLog.EndDate,
                    Comment = fileLog.Comment,
                    Roe = fileLog.Roe
                });
                _context.SaveChanges();
            }
           
            if (columnName == "enterDate")
            {
                DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                fileLog.ContainerMaster.FileMaster.EnterDate = dateTime;
                _context.FileMaster.Update(fileLog.ContainerMaster.FileMaster);
                _context.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "fileNumber")
            {
                fileList = fileList.Where(x => x.Id == fileId).ToList();
                string pattern = @"^[A-Z]{3}\/[A-Z]{3}\/\d{7}\/\d{2}\/\d{2}$";
                if (!Regex.IsMatch(editedValue, pattern))
                {
                    return Json("Invalid file format.");
                }
                else
                {
                    var fileList1 = fileList.Where(x => x.FileNumber == editedValue).ToList();
                    if (fileList1.Count() != 0)
                    {
                        return Json("Duplicate File.");
                    }
                    else
                    {
                        fileLog.ContainerMaster.FileMaster.FileNumber = editedValue;
                        _context.FileMaster.Update(fileLog.ContainerMaster.FileMaster);
                        _context.FileActivityLog.Update(fileLog);
                    }
                }
            }
            else if (columnName == "containerNo")
            {
                fileLog.ContainerMaster.ContainerNo = editedValue;
                _context.ContainerMaster.Update(fileLog.ContainerMaster);
                _context.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "siCutOff")
            {
                //fileLog.ContainerMaster.SICutOff = Convert.ToDateTime(editedValue).ToUniversalTime();
                fileLog.ContainerMaster.SICutOff = Convert.ToDateTime(editedValue);
                _context.ContainerMaster.Update(fileLog.ContainerMaster);
                _context.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "roe")
            {
                fileLog.Roe = editedValue;
                _context.FileActivityLog.Update(fileLog);
            }
           
            _context.SaveChanges();
            return Json("Success");
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult ActivateActivity(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ActivityMaster master = _context.ActivityMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _context.ActivityMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.NameOfActivity + " Activity Activated!" : master.NameOfActivity + " Activity Deactivated!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult DeleteActivity(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ActivityMaster master = _context.ActivityMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.ActivityMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.NameOfActivity + " Activity Deleted!" : master.NameOfActivity + " Activity Restore!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }


        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult ActivateCountry(string Id)
        {
            string message = "";
            if (Id != null)
            {
                CountryMaster master = _context.CountryMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _context.CountryMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.CountryName + " Country Activated!" : master.CountryName + " Country Deactivated!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult DeleteCountry(string Id)
        {
            string message = "";
            if (Id != null)
            {
                CountryMaster master = _context.CountryMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.CountryMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.CountryName + " Country Deleted!" : master.CountryName + " Country Restore!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult ActivateStatus(string Id)
        {
            string message = "";
            if (Id != null)
            {
                StatusMaster master = _context.StatusMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _context.StatusMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.Status + " Status Activated!" : master.Status + " Status Deactivated!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult DeleteStatus(string Id)
        {
            string message = "";
            if (Id != null)
            {
                StatusMaster master = _context.StatusMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.StatusMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.Status + " Status Deleted!" : master.Status + " Status Restore!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult ActivateUser(string Id)
            {
            string message = "";
            if (Id != null)
            {
                ApplicationUser master = _context.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _context.Users.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.UserName + " User Activated!" : master.UserName + " User Deactivated!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult DeleteUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ApplicationUser master = _context.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.Users.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.UserName + " User Deleted!" : master.UserName + " User Restore!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult UpdateIsLDAP(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ApplicationUser master = _context.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsLDAP = master.IsLDAP != null ? !master.IsLDAP : true;
                    _context.Users.Update(master);
                    _context.SaveChanges();
                    message = master.IsLDAP == true ? master.UserName + " LDAP Active!" : master.UserName + " LDAP InActive!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult UpdateIsReset(string Id)
        {
            string message = "";
            ApplicationUser master = _context.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
            if (Id != null)
            {
                if (master != null)
                {
                    master.IsReset = master.IsReset != null ? !master.IsReset : true;
                    _context.Users.Update(master);
                    _context.SaveChanges();
                    message = master.IsReset == true ? master.UserName + " Password Unset!" : master.UserName + " Password Reset!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(new { Message = message, UserName = master.UserName, CitrixId = master.CitrixId, UserId = master.Id });
        }

        public IActionResult EditFile(string id)
        {
            //DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);
            //var file = _context.ContainerMaster.Include(x => x.FileMaster).Include(x => x.FileMaster.CountryMaster).Where(x => x.Id == id).FirstOrDefault();
            List<FileDashModel> fileDashModel = new List<FileDashModel>();

            //var data = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= date.Date - TimeSpan.FromDays(10) || x.SICutOff.Value.Date == null).Include(x => x.FileMaster).Include(x => x.FileActivityLogs).ThenInclude(x => x.ApplicationUser).Select(x => new FileDashModel
            var data = _context.ContainerMaster.Where(x => x.Id == id).Include(x => x.FileMaster).Include(x => x.FileActivityLogs).ThenInclude(x => x.ApplicationUser).Select(x => new FileDashModel
            {
                Id = x.FileMaster.Id,
                FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                EnterDate = x.FileMaster.EnterDate,
                FileNumber = x.FileMaster.FileNumber,
                POD = x.FileMaster.CountryMaster.CountryName,
                CountryId = x.FileMaster.POD,
                ETD = x.FileMaster.ETD,
                ETAPOD = x.FileMaster.ETAPOD,
                ETA = x.FileMaster.ETA,
                ATD = x.FileMaster.ATD,
                SICutOff = x.SICutOff,
                ShippingLine = x.FileMaster.ShippingLine,
                FileContact = x.FileMaster.FileContact,
                FileActivityLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Id,
                UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                ContainerNo = x.ContainerNo,
                ContainerId = x.Id,
                Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                Roe = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Roe != null).FirstOrDefault().Roe,
                LBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count(),
                TBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
                TotalHBL = x.HBLMasters.Where(y => y.ContainerId == x.Id).Count() != 0 ? (x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : x.FileMaster.TotalBL
            }).AsQueryable();


            //IQueryable<FileDashModel> SortedData = file.Where(x => x.ContainerId == id).AsQueryable();
            ViewData["EditFile"] = data.FirstOrDefault();
            ViewData["Country"] = _context.CountryMaster.OrderBy(x => x.CountryName).ToList();
            ViewData["Status"] = _context.StatusMaster.OrderBy(x => x.Status).ToList();
            return PartialView(/*"EditFile", file*/);
        }

        //[HttpPost]
        //public async Task<JsonResult> EditFile(FileDashModel model)
        //{
        //    var container = _context.ContainerMaster.Where(x => x.Id == model.ContainerId && x.FileId == model.Id).Include(x => x.FileMaster).Include(x => x.FileActivityLogs).ThenInclude(x => x.ApplicationUser).FirstOrDefault();
        //    if (container != null)
        //    {
        //        container.FileMaster.FileNumber = model.FileNumber == null ? null : model.FileNumber.Trim();
        //        //container.ContainerNo = model.ContainerNo == null ? null : model.ContainerNo.Trim();
        //        container.FileMaster.EnterDate = model.EnterDate == null ? (DateTime?)null : Convert.ToDateTime(model.EnterDate).ToUniversalTime();
        //        container.FileMaster.POD = model.POD == null ? null : model.POD;
        //        container.FileMaster.ETD = model.ETD == null ? (DateTime?)null : Convert.ToDateTime(model.ETD).ToUniversalTime();
        //        container.FileMaster.ATD = model.ATD == null ? (DateTime?)null : Convert.ToDateTime(model.ATD).ToUniversalTime();
        //        container.FileMaster.ETAPOD = model.ETAPOD == null ? (DateTime?)null : Convert.ToDateTime(model.ETAPOD).ToUniversalTime();
        //        container.FileMaster.ETA = model.ETA == null ? (DateTime?)null : Convert.ToDateTime(model.ETA).ToUniversalTime();
        //        container.FileMaster.ShippingLine = model.ShippingLine == null ? null : model.ShippingLine;
        //        container.FileMaster.FileContact = model.FileContact == null ? null : model.FileContact;
        //        //container.FileMaster.ETA = model.ETA == null ? (DateTime?)null : Convert.ToDateTime(model.ETA).ToUniversalTime();
        //        container.FileMaster.TotalBL = model.TotalHBL;
        //        if (model.ContainerId == container.Id)
        //        {
        //            if (model.ContainerNo == null)
        //            {
        //                container.ContainerNo = null;
        //                _context.ContainerMaster.Update(container);
        //            }
        //            else
        //            {
        //                if (model.ContainerNo == container.ContainerNo)
        //                {
        //                    container.SICutOff = model.SICutOff == null ? (DateTime?)null : Convert.ToDateTime(model.SICutOff).ToUniversalTime();
        //                }
        //                else
        //                {
        //                    container.ContainerNo = model.ContainerNo.Trim();
        //                    container.SICutOff = model.SICutOff == null ? (DateTime?)null : Convert.ToDateTime(model.SICutOff).ToUniversalTime();
        //                }

        //                _context.ContainerMaster.Update(container);
        //            }
        //        }
        //        else
        //        {
        //            _context.ContainerMaster.Add(new ContainerMaster
        //            {
        //                ContainerNo = model.ContainerNo?.Trim(),
        //                SICutOff = model.SICutOff == null ? (DateTime?)null : Convert.ToDateTime(model.SICutOff).ToUniversalTime()
        //            });
        //        }

        //        _context.SaveChanges();
        //        //container.ContainerNo = model.ContainerNo == null ? null : model.ContainerNo.Trim();
        //        //container.SICutOff = model.SICutOff == null ? (DateTime?)null : Convert.ToDateTime(model.SICutOff).ToUniversalTime();
        //        //_context.ContainerMaster.Update(container);
        //        _context.FileMaster.Update(container.FileMaster);
        //        _context.SaveChanges();
        //        return Json("Updated Successfully..!");
        //    }
        //    else
        //    {
        //        return Json("Error while processing the request");
        //    }
        //}
        
        [HttpPost]
        public async Task<JsonResult> EditFile(FileDashModel model)
        {
            // Fetch the container and its related data
            var container = _context.ContainerMaster
                .Where(x => x.Id == model.ContainerId && x.FileId == model.Id)
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                .ThenInclude(x => x.ApplicationUser)
                .FirstOrDefault();

            if (container != null)
            {
                // Update FileMaster details
                container.FileMaster.FileNumber = model.FileNumber?.Trim();
                container.FileMaster.EnterDate = model.EnterDate.HasValue ? model.EnterDate.Value.ToUniversalTime() : (DateTime?)null;
                container.FileMaster.POD = model.POD;
                container.FileMaster.ETD = model.ETD.HasValue ? model.ETD.Value.ToUniversalTime() : (DateTime?)null;
                container.FileMaster.ATD = model.ATD.HasValue ? model.ATD.Value.ToUniversalTime() : (DateTime?)null;
                container.FileMaster.ETAPOD = model.ETAPOD.HasValue ? model.ETAPOD.Value.ToUniversalTime() : (DateTime?)null;
                container.FileMaster.ETA = model.ETA.HasValue ? model.ETA.Value.ToUniversalTime() : (DateTime?)null;
                container.FileMaster.ShippingLine = model.ShippingLine;
                container.FileMaster.FileContact = model.FileContact;
                container.FileMaster.TotalBL = model.TotalHBL;

                // Check if the container ID matches and update or add container details
                if (model.ContainerId == container.Id)
                {
                    if (string.IsNullOrEmpty(model.ContainerNo))
                    {
                        container.ContainerNo = null;
                        //container.SICutOff = model.SICutOff.HasValue ? model.SICutOff.Value.ToUniversalTime() : (DateTime?)null;
                        container.SICutOff = model.SICutOff.HasValue ? model.SICutOff.Value : (DateTime?)null;
                    }
                    else
                    {
                        container.ContainerNo = model.ContainerNo.Trim();
                        //container.SICutOff = model.SICutOff.HasValue ? model.SICutOff.Value.ToUniversalTime() : (DateTime?)null;
                        container.SICutOff = model.SICutOff.HasValue ? model.SICutOff.Value : (DateTime?)null;
                    }

                    _context.ContainerMaster.Update(container);
                }
                else
                {
                    // Add a new container if sicutthe ContainerId does not match
                    _context.ContainerMaster.Add(new ContainerMaster
                    {
                        ContainerNo = model.ContainerNo?.Trim(),
                        //SICutOff = model.SICutOff.HasValue ? model.SICutOff.Value.ToUniversalTime() : (DateTime?)null,
                        SICutOff = model.SICutOff.HasValue ? model.SICutOff.Value : (DateTime?)null,
                        FileId = model.Id
                    });
                }

                // Update FileMaster and save changes
                _context.FileMaster.Update(container.FileMaster);
                await _context.SaveChangesAsync();

                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }


    }
}
